# 30246196_Project_Shop
Online shop with  Solar Panels and Heat Pumps, Customers and Staff, ASSESSMENTS
